'use client'

import { useEffect, useState, useCallback } from 'react'
import { useSearchParams } from 'next/navigation'
import toast from 'react-hot-toast'
import Image from 'next/image'

interface OrderData {
  orderNo: string
  amount: number
  cardType: string
  duration: number
  payStatus: number
}

interface PaymentMethod {
  id: string
  name: string
  icon: string
  qrCode: string
  instructions: string
}

export default function PayPage() {
  const searchParams = useSearchParams()
  const orderNo = searchParams.get('orderNo')

  const [order, setOrder] = useState<OrderData | null>(null)
  const [methods, setMethods] = useState<PaymentMethod[]>([])
  const [selectedMethod, setSelectedMethod] = useState<string>('')
  const [loading, setLoading] = useState(true)
  const [checking, setChecking] = useState(false)
  const [paid, setPaid] = useState(false)
  const [cardCode, setCardCode] = useState('')

  useEffect(() => {
    if (orderNo) {
      fetchOrder()
      fetchPaymentMethods()
    }
  }, [orderNo])

  const fetchOrder = async () => {
    try {
      const res = await fetch(`/api/orders?orderNo=${orderNo}`)
      const data = await res.json()
      if (data.success) {
        setOrder(data.data)
        if (data.data.payStatus === 1) {
          setPaid(true)
          setCardCode(data.data.cardCode)
        }
      } else {
        toast.error(data.message)
      }
    } catch (error) {
      toast.error('獲取訂單失敗')
    }
  }

  const fetchPaymentMethods = async () => {
    try {
      const res = await fetch('/api/payment')
      const data = await res.json()
      if (data.success) {
        setMethods(data.data)
        if (data.data.length > 0) {
          setSelectedMethod(data.data[0].id)
        }
      }
    } catch (error) {
      toast.error('獲取支付方式失敗')
    } finally {
      setLoading(false)
    }
  }

  const checkPayment = useCallback(async () => {
    if (checking || paid) return

    setChecking(true)
    try {
      const res = await fetch(`/api/orders?orderNo=${orderNo}`)
      const data = await res.json()
      if (data.success && data.data.payStatus === 1) {
        setPaid(true)
        setCardCode(data.data.cardCode)
        toast.success('支付成功！')
      }
    } catch (error) {
      console.error('檢查支付狀態失敗')
    } finally {
      setChecking(false)
    }
  }, [orderNo, checking, paid])

  // 每10秒檢查一次支付狀態（供手動確認後輪詢）
  useEffect(() => {
    if (!paid && order?.payStatus === 0) {
      const interval = setInterval(checkPayment, 10000)
      return () => clearInterval(interval)
    }
  }, [paid, order, checkPayment])

  const copyOrderNo = () => {
    if (orderNo) {
      navigator.clipboard.writeText(orderNo)
      toast.success('訂單號已複製')
    }
  }

  const getDurationText = (days: number) => {
    if (days === 1) return '1天'
    if (days === 7) return '7天'
    if (days === 30) return '30天'
    if (days === 365) return '365天'
    return `${days}天`
  }

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-blue-50 to-indigo-100">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-500"></div>
      </div>
    )
  }

  if (!order) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-blue-50 to-indigo-100">
        <div className="text-center">
          <h1 className="text-2xl font-bold text-gray-900 mb-4">訂單不存在</h1>
          <a href="/" className="text-blue-600 hover:underline">返回首頁</a>
        </div>
      </div>
    )
  }

  if (paid) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-green-50 to-emerald-100 py-12 px-4">
        <div className="max-w-2xl mx-auto">
          <div className="bg-white rounded-2xl shadow-xl p-8 text-center">
            <div className="w-20 h-20 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-6">
              <svg className="w-10 h-10 text-green-500" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
              </svg>
            </div>

            <h1 className="text-3xl font-bold text-gray-900 mb-4">支付成功！</h1>
            <p className="text-gray-600 mb-8">您的卡密已準備就緒，請妥善保存</p>

            <div className="bg-gray-50 rounded-xl p-6 mb-6">
              <p className="text-sm text-gray-500 mb-2">卡密（{getDurationText(order.duration)}）</p>
              <p className="text-2xl font-mono font-bold text-blue-600 break-all">{cardCode}</p>
            </div>

            <p className="text-sm text-gray-500 mb-6">卡密已同時發送到您的郵箱</p>

            <a 
              href="/"
              className="inline-block bg-blue-600 hover:bg-blue-700 text-white font-bold py-3 px-8 rounded-xl transition-all"
            >
              返回首頁
            </a>
          </div>
        </div>
      </div>
    )
  }

  const currentMethod = methods.find(m => m.id === selectedMethod)

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 py-12 px-4">
      <div className="max-w-2xl mx-auto">
        {/* Order Info */}
        <div className="bg-white rounded-2xl shadow-lg p-6 mb-6">
          <div className="flex justify-between items-center mb-4">
            <h1 className="text-2xl font-bold text-gray-900">支付訂單</h1>
            <span className="text-2xl font-bold text-blue-600">HK${order.amount}</span>
          </div>

          <div className="bg-blue-50 rounded-xl p-4 mb-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">訂單號碼</p>
                <p className="text-xl font-mono font-bold text-blue-700">{order.orderNo}</p>
              </div>
              <button
                onClick={copyOrderNo}
                className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
              >
                複製
              </button>
            </div>
            <p className="text-sm text-orange-600 mt-2">⚠️ 付款時請務必在備註填寫此訂單號</p>
          </div>

          <div className="flex justify-between text-sm text-gray-600">
            <span>套餐：{getDurationText(order.duration)}</span>
            <span>狀態：等待付款</span>
          </div>
        </div>

        {/* Payment Methods */}
        <div className="bg-white rounded-2xl shadow-lg p-6 mb-6">
          <h2 className="text-lg font-bold text-gray-900 mb-4">選擇支付方式</h2>

          <div className="grid grid-cols-2 gap-3 mb-6">
            {methods.map((method) => (
              <button
                key={method.id}
                onClick={() => setSelectedMethod(method.id)}
                className={`
                  p-4 rounded-xl border-2 text-left transition-all
                  ${selectedMethod === method.id
                    ? 'border-blue-500 bg-blue-50'
                    : 'border-gray-200 hover:border-blue-300'
                  }
                `}
              >
                <p className="font-bold text-gray-900">{method.name}</p>
              </button>
            ))}
          </div>

          {currentMethod && (
            <div className="text-center">
              <div className="bg-gray-50 rounded-xl p-6 mb-4">
                {currentMethod.qrCode ? (
                  <div className="relative w-64 h-64 mx-auto bg-white p-4 rounded-lg">
                    <Image
                      src={currentMethod.qrCode}
                      alt={currentMethod.name}
                      fill
                      className="object-contain p-4"
                    />
                  </div>
                ) : (
                  <div className="w-64 h-64 mx-auto bg-gray-200 rounded-lg flex items-center justify-center">
                    <p className="text-gray-500">請配置收款二維碼</p>
                  </div>
                )}
              </div>

              <div className="bg-yellow-50 border border-yellow-200 rounded-xl p-4 mb-4">
                <p className="text-sm text-yellow-800">
                  <span className="font-bold">操作步驟：</span>
                  {currentMethod.instructions}
                </p>
              </div>

              {currentMethod.id === 'payme' && process.env.NEXT_PUBLIC_PAYME_LINK && (
                <a
                  href={process.env.NEXT_PUBLIC_PAYME_LINK}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="inline-block w-full bg-pink-600 hover:bg-pink-700 text-white font-bold py-3 px-6 rounded-xl transition-all mb-4"
                >
                  打開 PayMe 付款
                </a>
              )}
            </div>
          )}
        </div>

        {/* Status Check */}
        <div className="bg-white rounded-2xl shadow-lg p-6 text-center">
          <p className="text-gray-600 mb-4">完成付款後，系統會自動確認</p>
          <div className="flex items-center justify-center space-x-2 text-sm text-gray-500">
            <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-blue-500"></div>
            <span>等待付款確認...（每10秒自動檢查）</span>
          </div>
          <p className="text-xs text-gray-400 mt-4">
            如果已付款但未自動確認，請聯繫客服手動處理
          </p>
        </div>
      </div>
    </div>
  )
}
